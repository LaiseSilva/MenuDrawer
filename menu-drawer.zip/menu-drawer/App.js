import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';

import Constants from 'expo-constants';


import MyDrawer from './components/menuDrawer'

export default function App() {
  return (
     <NavigationContainer>
      <MyDrawer />
    </NavigationContainer>
  );
}

