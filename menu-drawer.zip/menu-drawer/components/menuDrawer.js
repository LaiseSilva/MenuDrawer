import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem} from '@react-navigation/drawer';

   function CustomDrawerContent(props) {
  return (
    <DrawerContentScrollView {...props}>
      <DrawerItemList {...props} />
      <DrawerItem
        label="Fechar menu"
        onPress={() => props.navigation.closeDrawer()}
      />
    </DrawerContentScrollView>
  );}

import RegisterPacient from '../screens/registerPacient'
import ListPacients from '../screens/listPacient'
import ListNotifications from '../screens/notifications'

const Drawer = createDrawerNavigator();

const MyDrawer = () => {
  return (
    <Drawer.Navigator
      useLegacyImplementation
      drawerContent={(props) => <CustomDrawerContent {...props} />}
    >
      <Drawer.Screen name="Cadastrar Pacientes" component={RegisterPacient} />
      <Drawer.Screen name="Listar Pacientes" component={ListPacients} />
      <Drawer.Screen name="Notificações" component={ListNotifications} />
    </Drawer.Navigator>
  );
}

export default MyDrawer;